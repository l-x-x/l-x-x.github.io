// popup.js

const PRL_SECTIONS = {
    'a': { "name": "Quantum Information, Science, and Technology", "field_cn": "量子信息、科学与技术" },
    'b': { "name": "Cosmology, Astrophysics, and Gravitation", "field_cn": "宇宙学、天体物理学与引力" },
    'c': { "name": "Particles and Fields", "field_cn": "基本粒子与场论" },
    'd': { "name": "Nuclear Physics", "field_cn": "核物理" },
    'e': { "name": "Atomic, Molecular, and Optical Physics", "field_cn": "原子、分子与光学物理" },
    'f': { "name": "Physics of Fluids, Earth & Planetary Science, and Climate", "field_cn": "流体物理、地球与行星科学及气候" },
    'g': { "name": "Plasma and Solar Physics, Accelerators and Beams", "field_cn": "等离子体与太阳物理、加速器与束流" },
    'h': { "name": "Condensed Matter and Materials", "field_cn": "凝聚态物质与材料" },
    'i': { "name": "Statistical Physics; Classical, Nonlinear, and Complex Systems", "field_cn": "统计物理、经典非线性与复杂系统" },
    'j': { "name": "Polymers, Chemical Physics, Soft Matter, and Biological Physics", "field_cn": "高分子、化学物理、软物质与生物物理" }
};

// --- Event Listeners ---
document.addEventListener('DOMContentLoaded', initializePopup);
document.getElementById('saveKey').addEventListener('click', saveSettings);
document.getElementById('startExtraction').addEventListener('click', startProcess);
document.getElementById('copyResults').addEventListener('click', copyResultsAsRichText);
document.getElementById('pauseResume').addEventListener('click', pauseResumeTask);
document.getElementById('abortTask').addEventListener('click', abortTask);
document.getElementById('resultsSection').addEventListener('click', handleResultsClick);


chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'UPDATE_STATE') {
        updateUI(message.state);
    } else if (message.type === 'DEBUG_MESSAGE') {
        displayDebugInfo(message.content);
    } else if (message.type === 'API_MONITOR_UPDATE') {
        updateApiMonitor(message.log);
    } else if (message.type === 'EXTRACTION_MONITOR_UPDATE') {
        updateExtractionMonitor(message.log);
    }
});

// --- UI Functions ---
async function initializePopup() {
    const sectionSelector = document.getElementById('sectionSelector');
    for (const key in PRL_SECTIONS) {
        const option = document.createElement('option');
        option.value = key;
        option.textContent = `${key.toUpperCase()}: ${PRL_SECTIONS[key].name}`;
        sectionSelector.appendChild(option);
    }
    const data = await chrome.storage.local.get(['apiKey', 'editorNames', 'taskState', 'lastSelectedSection']);
    if (data.apiKey) document.getElementById('apiKey').value = data.apiKey;
    if (data.editorNames) document.getElementById('editorNames').value = data.editorNames;
    if (data.lastSelectedSection) sectionSelector.value = data.lastSelectedSection;
    
    document.getElementById('debugSection').style.display = 'none';

    updateUI(data.taskState);

    try {
        const latestState = await chrome.runtime.sendMessage({ type: 'GET_LATEST_STATE' });
        if (latestState) {
            updateUI(latestState);
        }
    } catch (error) {
        console.warn("Could not get latest state from background. It might be inactive.", error);
    }
}

function updateUI(state) {
    const startButton = document.getElementById('startExtraction');
    const taskControls = document.getElementById('taskControls');
    const pauseResumeButton = document.getElementById('pauseResume');
    const copyButton = document.getElementById('copyResults');
    const resultsSection = document.getElementById('resultsSection');
    const statusSection = document.getElementById('statusSection');
    const statusText = document.getElementById('statusText');
    const loader = statusSection.querySelector('.loader');
    const apiMonitor = document.getElementById('apiMonitorSection');

    if (!state || state.status === 'idle' || state.status === 'aborted') {
        startButton.style.display = 'block';
        startButton.disabled = false;
        taskControls.style.display = 'none';
        
        if (state && state.progressMessage && (state.progressMessage.includes('完毕') || state.progressMessage.includes('终止'))) {
            statusSection.style.display = 'flex';
            loader.style.display = 'none';
        } else {
            statusSection.style.display = 'none';
        }
        
        statusText.textContent = state ? state.progressMessage : '';
        copyButton.style.display = state && state.resultsHTML ? 'block' : 'none';
        resultsSection.innerHTML = state ? state.resultsHTML : '';
    } else if (state.status === 'running' || state.status === 'paused') {
        startButton.style.display = 'none';
        taskControls.style.display = 'grid';
        pauseResumeButton.textContent = state.status === 'running' ? '暂停任务' : '继续任务';
        statusSection.style.display = 'flex';
        loader.style.display = 'block';
        statusText.textContent = state.status === 'paused' ? `已暂停 | ${state.progressMessage}` : state.progressMessage;
        copyButton.style.display = 'none';
        resultsSection.innerHTML = state.resultsHTML || '';
        apiMonitor.style.display = 'block'; 
    }
}

function displayDebugInfo(content) {
    const debugSection = document.getElementById('debugSection');
    const debugOutput = document.getElementById('debugOutput');
    if (debugSection && debugOutput) {
        debugOutput.value = content;
        debugSection.style.display = 'block';
        window.scrollTo(0, document.body.scrollHeight);
    }
}


function saveSettings() {
    const apiKey = document.getElementById('apiKey').value.trim();
    const editorNames = document.getElementById('editorNames').value.trim();
    if (apiKey) {
        chrome.storage.local.set({ apiKey, editorNames }, () => alert('API Key 和责任编辑已保存！'));
    } else {
        alert('请输入 API Key。');
    }
}

async function startProcess() {
    const { apiKey } = await chrome.storage.local.get('apiKey');
    if (!apiKey) {
        alert('请先输入并保存您的 DeepSeek API Key。');
        return;
    }
    
    const tabs = await chrome.tabs.query({ url: "https://journals.aps.org/prl/issues/*" });
    if (tabs.length === 0) {
        alert('错误：未找到打开的 PRL 期刊页面。请确保您已打开一个 PRL issue 页面。');
        return;
    }
    const tab = tabs[0]; 


    document.getElementById('debugSection').style.display = 'none';
    const monitor = document.getElementById('apiMonitorOutput');
    if(monitor) monitor.innerHTML = ''; 

    const selectedKey = document.getElementById('sectionSelector').value;
    chrome.storage.local.set({ lastSelectedSection: selectedKey });

    chrome.runtime.sendMessage({
        type: 'START_TASK',
        tabId: tab.id,
        apiKey: apiKey,
        section: PRL_SECTIONS[selectedKey],
        editorNames: document.getElementById('editorNames').value.trim()
    });
    alert('任务已在后台开始！您可以随时关闭此面板，任务将继续运行。');
}

function pauseResumeTask() {
    chrome.runtime.sendMessage({ type: 'PAUSE_RESUME_TASK' });
}

function abortTask() {
    if (confirm('您确定要终止当前任务吗？')) {
        chrome.runtime.sendMessage({ type: 'ABORT_TASK' });
    }
}

function handleResultsClick(event) {
    if (event.target.classList.contains('reprocess-button')) {
        const articleIndex = event.target.dataset.index;
        if (confirm(`您确定要重新提取和翻译第 ${parseInt(articleIndex) + 1} 篇文章吗？`)) {
            chrome.runtime.sendMessage({ type: 'REPROCESS_ARTICLE', index: parseInt(articleIndex) });
        }
    }
}


function copyResultsAsRichText() {
    const resultsContainer = document.getElementById('resultsSection');
    if (!resultsContainer.innerHTML) return;

    const contentToCopy = resultsContainer.cloneNode(true);
    contentToCopy.querySelectorAll('.reprocess-button').forEach(btn => btn.remove());
    contentToCopy.querySelectorAll('.article-entry').forEach(entry => {
        entry.style.border = 'none';
        entry.style.padding = '0';
        entry.style.margin = '0';
        entry.style.backgroundColor = 'transparent';
    });
    const finalHtml = contentToCopy.innerHTML;

    try {
        const listener = (e) => {
            e.clipboardData.setData('text/html', finalHtml);
            e.clipboardData.setData('text/plain', resultsContainer.innerText.replace(/🔄/g, ''));
            e.preventDefault();
        };
        document.addEventListener('copy', listener);
        document.execCommand('copy');
        document.removeEventListener('copy', listener);
        document.getElementById('copyFeedback').textContent = '复制成功！请直接粘贴到Word中。';
        setTimeout(() => { document.getElementById('copyFeedback').textContent = ''; }, 3000);
    } catch (err) {
        document.getElementById('copyFeedback').textContent = '复制失败！';
    }
}


/**
 * 更新API监控窗口的内容。
 * @param {object} log - 包含日志阶段和内容的日志对象。
 */
function updateApiMonitor(log) {
    const monitor = document.getElementById('apiMonitorOutput');
    if (!monitor) return;
    const timestamp = new Date().toLocaleTimeString();
    let logHTML = `<div><span style="color: #9cdcfe;">[${timestamp}]</span> `;

    if (log.stage === 'request') {
        logHTML += `<span style="color: #ce9178;">正在发送翻译请求...</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;"><strong>类型:</strong> ${escapeHtml(log.part_type)}<br><strong>发送文本 (前300字符):</strong> ${escapeHtml(String(log.text).substring(0, 300))}...</div>`;
    } else if (log.stage === 'raw_response') {
        logHTML += `<span style="color: #b5cea8;">收到API原始响应</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;">${escapeHtml(log.raw_text)}</div>`;
    } else if (log.stage === 'response') {
        logHTML += `<span style="color: #4ec9b0;">解析并获取翻译</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;"><strong>翻译结果:</strong> ${escapeHtml(log.translation)}</div>`;
    } else if (log.stage === 'error') {
        logHTML += `<span style="color: #f44747;">API请求出错</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;">${escapeHtml(log.message)}</div>`;
    }
    logHTML += '</div>';

    monitor.innerHTML += logHTML;
    monitor.scrollTop = monitor.scrollHeight; 
}

/**
 * 对HTML特殊字符进行转义，防止日志内容破坏页面结构。
 * @param {string} unsafe - 可能包含HTML字符的原始字符串。
 * @returns {string} 转义后的安全字符串。
 */
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') {
        unsafe = JSON.stringify(unsafe);
    }
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

/**
 * 更新提取阶段的监控窗口内容。
 * @param {object} log - 包含日志阶段和内容的日志对象。
 */
function updateExtractionMonitor(log) {
    const monitor = document.getElementById('apiMonitorOutput');
    if (!monitor) return;
    const timestamp = new Date().toLocaleTimeString();
    let logHTML = `<div><span style="color: #9cdcfe;">[${timestamp}]</span> `;

    if (log.stage === 'start') {
        logHTML += `<span style="color: #c586c0;">🔗 正在打开文章页面...</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;">${escapeHtml(log.url)}</div>`;
    } else if (log.stage === 'load_success') {
        const isSlow = log.duration > 8000; // 超过8秒认为是慢速
        const color = isSlow ? '#f44747' : '#4ec9b0'; // 慢则红色，否则绿色
        const icon = isSlow ? '⚠️' : '✅';
        logHTML += `<span style="color: ${color};">${icon} 页面加载完毕 (耗时: ${log.duration}ms)</span>`;
    } else if (log.stage === 'extract_success') {
        logHTML += `<span style="color: #4ec9b0;">📄 标题和摘要提取成功</span>`;
    } else if (log.stage === 'error') {
        logHTML += `<span style="color: #f44747;">❌ 提取阶段出错</span>`;
        logHTML += `<div style="padding-left: 10px; border-left: 1px solid #555;">${escapeHtml(log.message)}</div>`;
    }
    logHTML += '</div>';

    monitor.innerHTML += logHTML;
    monitor.scrollTop = monitor.scrollHeight; // 自动滚动到底部
}
