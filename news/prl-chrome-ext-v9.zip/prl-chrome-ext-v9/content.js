// content.js

/**
 * A robust function that waits for MathJax to finish rendering within a given element.
 * It uses a MutationObserver with a debounced stability check.
 * @param {HTMLElement} element - The container element to watch for MathJax rendering.
 * @returns {Promise<void>} A promise that resolves when rendering is stable.
 */
function waitForMathJax(element) {
    return new Promise((resolve) => {
        const timeout = 20000; // 20-second overall timeout
        let stabilizationTimer = null;

        const observer = new MutationObserver(() => {
            // If a stabilization check is already scheduled, cancel it because the DOM is still changing.
            if (stabilizationTimer) {
                clearTimeout(stabilizationTimer);
            }

            // Schedule a check for after a short period of DOM inactivity.
            stabilizationTimer = setTimeout(() => {
                if (!element.querySelector('mjx-lazy')) {
                    // If, after 500ms of no changes, lazy elements are gone, we're stable.
                    console.log("MathJax rendering has stabilized.");
                    observer.disconnect();
                    clearTimeout(overallTimeout); // Clear the main safety timeout
                    resolve();
                }
            }, 500); // 500ms stabilization window.
        });

        // A safety timeout to prevent the script from hanging indefinitely.
        const overallTimeout = setTimeout(() => {
            console.warn("waitForMathJax timed out after 20 seconds. Proceeding anyway.");
            observer.disconnect();
            resolve();
        }, timeout);

        // Initial check: If MathJax is already done, resolve immediately.
        if (!element.querySelector('mjx-lazy')) {
            console.log("MathJax already rendered on initial check.");
            clearTimeout(overallTimeout);
            resolve();
        } else {
            // If not done, start observing for changes.
            observer.observe(element, { childList: true, subtree: true });
        }
    });
}


/**
 * 从文章详情页提取元数据（标题和摘要）。
 * @param {boolean} useSpecialParser - 是否需要使用针对动态内容的特殊解析方式。
 * @returns {Promise<{title: string, abstract: string}>}
 */
async function extractMetadata(useSpecialParser) {
    // 提取标题的逻辑保持不变
    const titleTag = document.querySelector('meta[property="og:title"]');
    const title = titleTag ? titleTag.getAttribute('content') : '标题提取失败 (未找到meta标签)';
    let abstract = '';

    if (useSpecialParser) {
        try {
            const abstractHeader = Array.from(document.querySelectorAll('h2')).find(
                h2 => h2.textContent.trim().toLowerCase() === 'abstract'
            );
            
            if (abstractHeader) {
                const abstractDiv = abstractHeader.nextElementSibling;
                if (abstractDiv && abstractDiv.matches('div.content')) {
                    const abstractParagraph = abstractDiv.querySelector('p');
                    if (abstractParagraph) {
                        await waitForMathJax(abstractParagraph);
                        await new Promise(resolve => setTimeout(resolve, 200));
                        abstract = abstractParagraph.innerHTML;
                    } else {
                         abstract = "摘要提取失败 (未找到摘要段落 - 特殊文章)";
                    }
                } else {
                    abstract = "摘要提取失败 (未找到摘要容器 - 特殊文章)";
                }
            } else {
                 abstract = "摘要提取失败 (未找到'Abstract'标题 - 特殊文章)";
            }
        } catch (error) {
            console.error("提取特殊文章摘要时出错:", error);
            abstract = "摘要提取异常 (特殊文章)";
        }
    } else {
        // --- 普通文章的逻辑保持不变 ---
        const descriptionTag = document.querySelector('meta[name="description"]');
        abstract = descriptionTag ? descriptionTag.getAttribute('content') : '摘要提取失败 (未找到meta标签)';
    }

    return { title, abstract };
}


/**
 * 从期刊主列表页抓取初步的文章信息。
 * @param {string} sectionName - 目标板块的完整名称。
 * @returns {Array<object>} 包含初步信息的文章对象数组。
 */
function getPreliminaryArticles(sectionName) {
    const sectionHeadings = Array.from(document.querySelectorAll('h1, h2, h3'));
    const targetHeading = sectionHeadings.find(h => h.textContent.trim().replace(/\s+/g, ' ') === sectionName);
    if (!targetHeading) return [];

    const parentSection = targetHeading.closest('section');
    const contentContainer = parentSection ? parentSection.querySelector('div.content') : null;
    if (!contentContainer) return [];

    const articleCards = contentContainer.querySelectorAll('div.browse-result-card');
    const preliminaryArticles = [];
    for (const card of articleCards) {
        const info = {
            link: 'N/A',
            authors: 'N/A',
            journal_reference: 'N/A',
            is_editors_suggestion: false,
            is_featured_in_physics: false, // 新增属性
            editors_blurb: "N/A"
        };

        const titleTag = card.querySelector('h3.title a, h4.title a');
        if (titleTag) {
            info.link = new URL(titleTag.getAttribute('href'), document.baseURI).href;
        }

        const citationSection = card.querySelector('section.citation-container');
        if (citationSection) {
            const pTags = citationSection.querySelectorAll('p');
            if (pTags.length > 0) info.authors = pTags[0].textContent.trim();
            if (pTags.length > 1) {
                const refText = pTags[1].textContent.trim().replace(/\s+/g, ' ');
                info.journal_reference = refText.split(/–|-/)[0].trim();
            }
        }
        
        // --- 更新的逻辑：同时检查两种特殊类型 ---
        const specialDivs = card.querySelectorAll('div.font-semibold');
        const specialDivsArray = Array.from(specialDivs);

        const isSuggestion = specialDivsArray.some(div => div.textContent.toUpperCase().includes("EDITORS' SUGGESTION"));
        const isFeatured = specialDivsArray.some(div => div.textContent.toUpperCase().includes("FEATURED IN PHYSICS"));

        if (isSuggestion) {
            info.is_editors_suggestion = true;
            const summarySection = card.querySelector('section.summary-container');
            if (summarySection) {
                const blurbContainer = summarySection.querySelector('div.self-stretch[class*="text-"]');
                if (blurbContainer) {
                    const blurbP = blurbContainer.querySelector('p');
                    if (blurbP) {
                        info.editors_blurb = blurbP.innerHTML;
                    }
                }
            }
        }

        if (isFeatured) {
            info.is_featured_in_physics = true;
        }
        
        preliminaryArticles.push(info);
    }
    return preliminaryArticles;
}

