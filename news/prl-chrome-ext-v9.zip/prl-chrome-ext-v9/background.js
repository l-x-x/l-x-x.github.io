// background.js

const DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions";
let panelWindowId = null;
let heartbeatInterval = null; // 用于存储心跳定时器

// ======================= 心跳功能 START =======================
function startHeartbeat() {
  // 如果已存在心跳，先清除
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
  }
  // 每隔15秒调用一个轻量级Chrome API来重置Service Worker的超时计时器
  heartbeatInterval = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {});
  }, 15000);
}

function stopHeartbeat() {
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
    heartbeatInterval = null;
  }
}
// ======================= 心跳功能 END =======================


// --- Logic to open the UI in a persistent panel window ---
chrome.action.onClicked.addListener((tab) => {
    const width = 540;
    const height = 720;
    if (panelWindowId) {
        chrome.windows.get(panelWindowId).then((win) => {
            if (chrome.runtime.lastError) { // Window was closed
                panelWindowId = null;
                createPanel();
            } else {
                chrome.windows.update(panelWindowId, { focused: true });
            }
        });
    } else {
        createPanel();
    }
    function createPanel() {
        chrome.windows.create({
            url: chrome.runtime.getURL("popup.html"),
            type: "popup",
            width: width,
            height: height,
        }, (win) => {
            panelWindowId = win.id;
        });
    }
});
chrome.windows.onRemoved.addListener((windowId) => {
    if (windowId === panelWindowId) {
        panelWindowId = null;
    }
});

// --- Message Listeners ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'START_TASK') {
        startNewTask(message.tabId, message);
    } else if (message.type === 'PAUSE_RESUME_TASK') {
        pauseResumeTask();
    } else if (message.type === 'ABORT_TASK') {
        abortTask();
    } else if (message.type === 'REPROCESS_ARTICLE') {
        reprocessSingleArticle(message.index);
    } else if (message.type === 'GET_LATEST_STATE') {
        chrome.storage.local.get('taskState').then(data => {
            sendResponse(data.taskState);
        });
        return true; // Indicates an asynchronous response
    }
    return true;
});

// --- State Management ---
async function updateState(newState) {
    const currentState = await chrome.storage.local.get('taskState');
    const updatedState = { ...currentState.taskState, ...newState };
    await chrome.storage.local.set({ taskState: updatedState });
    try {
        await chrome.runtime.sendMessage({ type: 'UPDATE_STATE', state: updatedState });
    } catch (e) { /* Popup might be closed, this is fine */ }
    return updatedState;
}

// --- Task Control Functions ---
async function startNewTask(tabId, taskDetails) {
    await updateState({
        status: 'running',
        progressMessage: '正在准备...',
        articlesToProcess: [],
        processedArticles: [],
        resultsHTML: '',
        taskPhase: 'extraction',
        currentConfig: {
            tabId: tabId,
            apiKey: taskDetails.apiKey,
            section: taskDetails.section,
            editorNames: taskDetails.editorNames
        }
    });
    startHeartbeat();
    processQueue();
}

async function pauseResumeTask() {
    const state = await updateState({});
    if (state.status === 'running') {
        await updateState({ status: 'paused' });
    } else if (state.status === 'paused') {
        await updateState({ status: 'running' });
        processQueue();
    }
}

async function abortTask() {
    const state = (await chrome.storage.local.get('taskState')).taskState;
    if (!state) return;
    const finalHTML = generateFinalOutput(state.processedArticles, state.currentConfig.section, state.currentConfig.editorNames);
    await updateState({ status: 'aborted', progressMessage: '任务已终止。', resultsHTML: finalHTML.html });
    stopHeartbeat();
}

function parseSpecialArticleHTML(htmlString) {
    if (!htmlString) return "";
    const withMath = htmlString.replace(/<mjx-container.*?data-semantic-speech-none="(.*?)".*?>.*?<\/mjx-container>/g, (match, speech) => {
        let simplified = speech.trim()
            .replace(/\s*sub\s*/g, '')
            .replace(/\s*super\s*/g, '^')
            .replace(/\s*raised to the\s*/g, '^')
            .replace(/\s*power\s*/g, '')
            .replace(/\s*normal\s*/g, '')
            .replace(/\s*divided by\s*/g, '/')
            .replace(/\s*tilde\s*/g, '~')
            .replace(/\s*plus\s*/g, '+')
            .replace(/\s*l n of\s*/g, 'ln')
            .replace(/\s*equals\s*/g, '=')
            .replace(/\s+/g, '');
        return `$${simplified}$`;
    });
    const plainText = withMath.replace(/<[^>]*>/g, '');
    return plainText.replace(/\s+/g, ' ').trim();
}


// --- Core Processing Loop (Robust Architecture) ---
async function processQueue() {
    let state = (await chrome.storage.local.get('taskState')).taskState;
    if (!state || state.status !== 'running') return;

    try {
        if (state.articlesToProcess.length === 0 && state.processedArticles.length === 0) {
            await updateState({ progressMessage: '正在刷新页面以获取最新链接...' });
            await chrome.tabs.reload(state.currentConfig.tabId);
            await waitForTabComplete(state.currentConfig.tabId);

            state = (await chrome.storage.local.get('taskState')).taskState;
            if (state.status !== 'running') return;
            
            await updateState({ progressMessage: '第一步：正在从主列表页提取文章链接...' });
            await chrome.scripting.executeScript({ target: { tabId: state.currentConfig.tabId }, files: ["content.js"] });
            const response = await chrome.scripting.executeScript({
                target: { tabId: state.currentConfig.tabId },
                func: (sectionName) => getPreliminaryArticles(sectionName),
                args: [state.currentConfig.section.name]
            });
            const articles = response[0].result;
            if (!articles || articles.length === 0) throw new Error('未能从主列表页提取到任何文章。');
            
            state = await updateState({ articlesToProcess: articles, progressMessage: `检测到 ${articles.length} 篇文章。` });
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        state = (await chrome.storage.local.get('taskState')).taskState;
        if (!state || state.status !== 'running') return;

        if (state.taskPhase === 'extraction') {
            if (state.articlesToProcess.length > 0) {
                const article = state.articlesToProcess[0];
                const total = state.articlesToProcess.length + state.processedArticles.length;
                const currentNum = state.processedArticles.length + 1;
                await processArticleForExtraction(article, currentNum, total);

                if ((await chrome.storage.local.get('taskState')).taskState.status === 'running') {
                    setTimeout(processQueue, 100);
                }
            } else {
                await updateState({ taskPhase: 'translation' });
                setTimeout(processQueue, 100);
            }
            return;
        }

        if (state.taskPhase === 'translation') {
            const articleToTranslateIndex = state.processedArticles.findIndex(a => !a.translation_complete);
            if (articleToTranslateIndex !== -1) {
                const article = state.processedArticles[articleToTranslateIndex];
                const total = state.processedArticles.length;
                const currentNum = articleToTranslateIndex + 1;
                await processArticleForTranslation(article, currentNum, total, articleToTranslateIndex);
                
                if ((await chrome.storage.local.get('taskState')).taskState.status === 'running') {
                    setTimeout(processQueue, 100);
                }
            } else {
                await updateState({ status: 'idle', progressMessage: '所有任务处理完成！' });
                stopHeartbeat(); // 任务正常完成，停止心跳
                chrome.notifications.create({ type: 'basic', iconUrl: 'images/icon128.png', title: 'PRL 翻译任务完成', message: `已成功处理 ${state.processedArticles.length} 篇文章。` });
            }
        }
    } catch (error) {
        console.error('后台任务失败:', error);
        stopHeartbeat(); // 任务异常终止，停止心跳
        await updateState({ status: 'aborted', progressMessage: `任务失败: ${error.message}` });
    }
}

async function processArticleForExtraction(article, currentNum, total) {
    const articleLinkForStatus = article.link ? article.link.substring(0, 40) : "未知链接";
    await updateState({ progressMessage: `[${currentNum}/${total}] 正在提取: ${articleLinkForStatus}...` });
    
    try {
        const useSpecialParser = article.is_editors_suggestion || article.is_featured_in_physics;
        if (article.link && article.link !== 'N/A') {
            const metadata = await fetchMetadataInNewTab(article.link, useSpecialParser);
            article.title = metadata.title;
            article.abstract_raw = metadata.abstract;
            if (article.is_editors_suggestion) article.editors_blurb_raw = article.editors_blurb;
        } else {
            throw new Error("文章链接无效");
        }
    } catch (e) {
        article.title = `<span style="color: red;"><b>标题提取失败</b></span>`;
        article.abstract_raw = `<span style="color: red;"><b>摘要提取失败: ${e.message}</b></span>`;
    }

    const state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return;

    const newProcessed = [...state.processedArticles, article];
    const newToProcess = state.articlesToProcess.slice(1);
    const newResultsHTML = generateFinalOutput(newProcessed, state.currentConfig.section, state.currentConfig.editorNames);
    await updateState({ articlesToProcess: newToProcess, processedArticles: newProcessed, resultsHTML: newResultsHTML.html });
}

async function processArticleForTranslation(article, currentNum, total, index) {
    let state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return;

    // 创建文章对象的深拷贝，避免在异步操作中污染原始状态
    const articleToProcess = JSON.parse(JSON.stringify(article));

    // 使用这个全新的副本进行翻译
    const translatedArticle = await processArticleWithDeepSeek(articleToProcess, state.currentConfig.apiKey, state.currentConfig.section.field_cn, currentNum, total);
    
    state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return;

    translatedArticle.translation_complete = true;
    let updatedProcessedArticles = [...state.processedArticles];
    updatedProcessedArticles[index] = translatedArticle;
    const newResultsHTML = generateFinalOutput(updatedProcessedArticles, state.currentConfig.section, state.currentConfig.editorNames);
    await updateState({ processedArticles: updatedProcessedArticles, resultsHTML: newResultsHTML.html });
}

async function reprocessSingleArticle(index) {
    let state = (await chrome.storage.local.get('taskState')).taskState;
    if (!state || !state.processedArticles || state.processedArticles[index] === undefined) return;

    const originalStatus = state.status;
    let article = { ...state.processedArticles[index] };
    const total = state.processedArticles.length;

    article.translation_complete = false;
    article.title_cn = '';
    article.abstract_cn = '';
    article.editors_blurb_cn = '';
    article.title_en_formatted = '';

    await updateState({ status: 'running', progressMessage: `[${index + 1}/${total}] 正在重新提取...` });
    startHeartbeat(); 
    try {
        const useSpecialParser = article.is_editors_suggestion || article.is_featured_in_physics;
        if (article.link && article.link !== 'N/A') {
            const metadata = await fetchMetadataInNewTab(article.link, useSpecialParser);
            article.title = metadata.title;
            article.abstract_raw = metadata.abstract;
        } else {
            throw new Error("文章链接无效");
        }

        state = (await chrome.storage.local.get('taskState')).taskState;
        if (state.status !== 'running') {
             stopHeartbeat();
             return;
        }

        const translatedArticle = await processArticleWithDeepSeek(article, state.currentConfig.apiKey, state.currentConfig.section.field_cn, index + 1, total);
        
        state = (await chrome.storage.local.get('taskState')).taskState;
        if (state.status !== 'running' && originalStatus !== 'paused') {
             stopHeartbeat();
             return;
        }
        
        translatedArticle.translation_complete = true;
        let updatedProcessedArticles = [...state.processedArticles];
        updatedProcessedArticles[index] = translatedArticle;
        const newResultsHTML = generateFinalOutput(updatedProcessedArticles, state.currentConfig.section, state.currentConfig.editorNames);
        
        await updateState({
            processedArticles: updatedProcessedArticles,
            resultsHTML: newResultsHTML.html,
            status: originalStatus,
            progressMessage: `文章 #${index + 1} 已重新处理完毕。`
        });

    } catch (error) {
        console.error(`Error reprocessing article ${index}:`, error);
        article.title_cn = `<span style="color: red;"><b>重新处理失败</b></span>`;
        article.abstract_cn = `<span style="color: red;"><b>错误: ${error.message}</b></span>`;
        let updatedProcessedArticles = [...state.processedArticles];
        updatedProcessedArticles[index] = article;
        const newResultsHTML = generateFinalOutput(updatedProcessedArticles, state.currentConfig.section, state.currentConfig.editorNames);
        await updateState({
            processedArticles: updatedProcessedArticles,
            resultsHTML: newResultsHTML.html,
            status: originalStatus,
            progressMessage: `重新处理文章 #${index + 1} 失败。`
        });
    } finally {
        stopHeartbeat(); 
    }
}


// --- Helper Functions ---

function waitForTabComplete(tabId) {
    return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener);
            reject(new Error(`Tab ${tabId} did not complete loading within 30 seconds.`));
        }, 30000);

        const listener = (updatedTabId, changeInfo) => {
            if (updatedTabId === tabId && changeInfo.status === 'complete') {
                clearTimeout(timeout);
                chrome.tabs.onUpdated.removeListener(listener);
                setTimeout(resolve, 1000); 
            }
        };
        chrome.tabs.onUpdated.addListener(listener);
    });
}

async function fetchMetadataInNewTab(url, needsRefresh) {
    let tabId;
    let originalTabId = null; 

    try {
        await sendExtractionLog({ stage: 'start', url });
        const startTime = performance.now(); 

        const newTab = await chrome.tabs.create({ url: url, active: false });
        tabId = newTab.id;
        await waitForTabComplete(tabId);

        const endTime = performance.now(); 
        const duration = Math.round(endTime - startTime);
        await sendExtractionLog({ stage: 'load_success', duration });

        if (needsRefresh) {
            const state = (await chrome.storage.local.get('taskState')).taskState;
            if (state && state.currentConfig && state.currentConfig.tabId) {
                originalTabId = state.currentConfig.tabId;
            }

            await chrome.tabs.update(tabId, { active: true });
            
            await chrome.tabs.reload(tabId);
            await waitForTabComplete(tabId);
        }
        
        await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
        let response = await chrome.scripting.executeScript({
            target: { tabId },
            func: (useSpecialParser) => extractMetadata(useSpecialParser),
            args: [needsRefresh],
        });

        let result = (response && response[0]) ? response[0].result : null;

        if (result && result.abstract && result.abstract.includes('<mjx-lazy')) {
            console.warn(`检测到 lazy MathJax for ${url}。 正在重试一次...`);
            await chrome.tabs.reload(tabId);
            await waitForTabComplete(tabId);
            await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
            response = await chrome.scripting.executeScript({
                target: { tabId },
                func: (useSpecialParser) => extractMetadata(useSpecialParser),
                args: [needsRefresh],
            });
            result = (response && response[0]) ? response[0].result : null;
        }

        if (!result) {
            throw new Error("未能从目标页面注入的脚本中获取结果。");
        }
        
        await sendExtractionLog({ stage: 'extract_success' });
        return result;

    } catch (e) {
        await sendExtractionLog({ stage: 'error', message: e.message });
        console.error(`Error fetching metadata from ${url}:`, e);
        throw e;
    } finally {
        if (originalTabId) {
            try {
                await chrome.tabs.update(originalTabId, { active: true });
            } catch (focusError) {
                console.warn("无法切换回原始标签页:", focusError.message);
            }
        }
        
        if (tabId) setTimeout(() => chrome.tabs.remove(tabId), 200);
    }
}

async function processArticleWithDeepSeek(article, apiKey, physics_field, currentNum, total) {
    const processedArticle = { ...article };
    const articleTitleForStatus = (typeof article.title === 'string') ? article.title.substring(0, 25).replace(/\$.*?\$/g, '') : "未知标题";

    let state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return processedArticle;

    if (article.title && !article.title.includes("提取失败")) {
        await updateState({ progressMessage: `[${currentNum}/${total}] 正在翻译标题: ${articleTitleForStatus}...` });
        const titleResult = await callDeepSeek(article.title, "标题", apiKey, physics_field);
        processedArticle.title_cn = titleResult.chinese_translation;
        processedArticle.title_en_formatted = titleResult.formatted_english;
    } else {
        processedArticle.title_cn = article.title;
        processedArticle.title_en_formatted = "N/A";
    }

    state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return processedArticle;

    const useSpecialParser = article.is_editors_suggestion || article.is_featured_in_physics;
    const abstractToTranslate = useSpecialParser ? parseSpecialArticleHTML(article.abstract_raw) : article.abstract_raw;
    
    if (abstractToTranslate && !abstractToTranslate.includes("提取失败")) {
        await updateState({ progressMessage: `[${currentNum}/${total}] 正在翻译摘要: ${articleTitleForStatus}...` });
        const abstractResult = await callDeepSeek(abstractToTranslate, "摘要", apiKey, physics_field);
        processedArticle.abstract_cn = abstractResult.chinese_translation;
    } else {
        processedArticle.abstract_cn = abstractToTranslate;
    }

    state = (await chrome.storage.local.get('taskState')).taskState;
    if (state.status !== 'running') return processedArticle;

    if (article.is_editors_suggestion && article.editors_blurb_raw) {
        await updateState({ progressMessage: `[${currentNum}/${total}] 正在翻译编辑评语...` });
        const blurbToTranslate = parseSpecialArticleHTML(article.editors_blurb_raw);
        const blurbResult = await callDeepSeek(blurbToTranslate, "编辑评语", apiKey, physics_field);
        processedArticle.editors_blurb_cn = blurbResult.chinese_translation;
    }
    return processedArticle;
}

/**
 * 向popup页面发送提取阶段的监控日志。
 * @param {object} log - 要发送的日志对象。
 */
async function sendExtractionLog(log) {
    try {
        await chrome.runtime.sendMessage({ type: 'EXTRACTION_MONITOR_UPDATE', log });
    } catch (e) {
        // Popup页面可能已经关闭
    }
}

/**
 * 向popup页面发送API监控日志。
 * @param {object} log - 要发送的日志对象。
 */
async function sendApiMonitorUpdate(log) {
    try {
        await chrome.runtime.sendMessage({ type: 'API_MONITOR_UPDATE', log });
    } catch (e) {
        // Popup页面可能已经关闭
    }
}

async function callDeepSeek(text, part_type, apiKey, physics_field) {
    const default_return = { chinese_translation: `翻译失败 (${part_type})`, formatted_english: text };
    if (!text || text.trim().length < 5 || text.includes('<b>')) {
        return default_return;
    }
    const system_prompt = `你是一个专业的物理学学术翻译引擎，精通“${physics_field}”领域的术语。你的核心任务是进行精准翻译和符号格式化。`;
    const user_prompt_template = `**核心指令**:
1.  **专业术语翻译 (最高优先级)**: 必须使用“${physics_field}”领域内公认的、约定俗成的专业术语进行翻译。
2.  **格式化数学符号**: 对原文和译文中的数学内容进行格式化。数学内容被\`$...$\`包裹。
3.  **第三人称翻译**: 将原文中的第一人称 (如 'we', 'I', 'our') 翻译成客观的第三人称 (如 '作者', '研究者', '本文')。
**格式化规则 (必须严格遵守)**:
-   **<u>保持原始顺序 (最高优先级)</u>**: 转换符号时，**必须严格保持所有字符、符号和顶线的原始相对顺序**。
-   **移除定界符**: **最终输出中绝对不能再包含\`$...$\`符号**。
-   **优先使用Unicode**: 尽可能将LaTeX命令和描述转换为单个Unicode字符。
-   **处理特殊命令**: 例如 \`$\\overline{B}$\` 或 \`$\\bar{B}$\` 应转换为带有顶线的字符，如 \`B̅\`。
-   **<u>强制使用HTML角标 (关键规则)</u>**: 对于所有上下标，**必须**使用HTML的\`<sup>\`和\`<sub>\`标签。例如：\`$h_c$\` 必须转换为 \`h<sub>c</sub>\`，\`$10^{-5}$\` 必须转换为 \`10<sup>-5</sup>\`。**最终输出中绝不能保留原始的 \`_\` 或 \`^\` 符号。**
-   **处理自然语言描述**: 将描述性文本转换为数学符号。
**输出格式 (至关重要)**:
-   **必须返回一个严格的、不含任何额外解释的JSON对象**。
-   **确保返回一个结构完整的JSON**。
-   **<u>JSON转义规则 (最高优先级)</u>**: 在生成JSON时，如果"chinese_translation"或"formatted_english"的字符串值内部包含任何双引号(")，你必须将其转义为 \\"。例如， "a "quote" example" 必须写成 "a \\"quote\\" example"。这是一个强制性规则。
请严格按照以下格式返回:
\`\`\`json
{{
  "chinese_translation": "处理好数学符号和内部引号转义的中文翻译",
  "formatted_english": "处理好数学符号和内部引号转义的英文原文"
}}
\`\`\`
**待处理的英文${part_type}**:
"{text}"`;

    const prompt_text = user_prompt_template.replace(/{text}/g, text).replace(/{part_type}/g, part_type).replace(/{physics_field}/g, physics_field);
    const payload = { model: "deepseek-chat", messages: [{ role: "system", content: system_prompt }, { role: "user", content: prompt_text }], temperature: 0.1, max_tokens: 4000, stream: false };
    
    try {
        await sendApiMonitorUpdate({ stage: 'request', part_type, text });
        
        const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => {
                reject(new Error("请求超时 (29秒)"));
            }, 29000);
        });

        const response = await Promise.race([
            fetch(DEEPSEEK_API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
                body: JSON.stringify(payload)
            }),
            timeoutPromise
        ]);

        if (!response.ok) throw new Error(`API 请求失败: ${response.status}`);
        const data = await response.json();
        const response_text = data.choices[0].message.content;
        
        await sendApiMonitorUpdate({ stage: 'raw_response', raw_text: response_text });
        
        let parsed_json = {};
        const cn_match = response_text.match(/"chinese_translation":\s*"(.*?)"\s*,\s*"formatted_english"/s);
        const en_match = response_text.match(/"formatted_english":\s*"(.*?)"\s*}/s);

        if (cn_match && cn_match[1] && en_match && en_match[1]) {
            parsed_json = {
                chinese_translation: cn_match[1].replace(/\\"/g, '"').replace(/\$(.*?)\$/g, '$1'),
                formatted_english: en_match[1].replace(/\\"/g, '"').replace(/\$(.*?)\$/g, '$1')
            };
        } else {
            await sendApiMonitorUpdate({ stage: 'error', message: "正则提取翻译内容失败，请检查API返回格式。" });
            console.error("正则提取翻译内容失败:", response_text);
            return default_return;
        }
        
        await sendApiMonitorUpdate({ stage: 'response', translation: parsed_json.chinese_translation });

        return { 
            chinese_translation: parsed_json.chinese_translation || default_return.chinese_translation, 
            formatted_english: parsed_json.formatted_english || default_return.formatted_english 
        };
    } catch (error) {
        await sendApiMonitorUpdate({ stage: 'error', message: error.message || "未知错误" });
        
        if (error.message.includes("超时")) {
            console.error("DeepSeek API call timed out via Promise.race.");
            return { chinese_translation: `<span style="color: orange;">翻译超时 (${part_type})</span>`, formatted_english: text };
        }

        console.error("调用DeepSeek API时出错:", error);
        return default_return;
    }
}

function generateFinalOutput(articles, section, editorNames) {
    const baseStyle = `font-family: 'Times New Roman', serif; font-size: 12pt;`;
    const cnStyle = `font-family: '宋体', 'SimSun', serif;`;
    let html = `<div style="${baseStyle}">`;
    html += `<p style="text-align: center; ${cnStyle} font-size: 22pt; font-weight: bold;">PRL期刊文章翻译</p>`;
    html += `<p style="text-align: center;">(期刊来源页面)</p>`;
    html += `<br/>`;
    html += `<p style="text-align: center;">目标板块: ${section.name}</p>`;
    html += `<p style="text-align: center;">共处理 ${articles.length} 篇文章</p>`;
    html += `<p style="text-align: center; ${cnStyle} font-size: 15pt;">${section.field_cn}</p>`;
    if (editorNames) {
        html += `<p style="text-align: center; ${cnStyle} font-size: 15pt;">责编： ${editorNames}</p>`;
    }
    articles.forEach((article, index) => {
        html += `<div class="article-entry" style="page-break-before: always;">`;
        html += `<button data-index="${index}" class="reprocess-button" title="重新提取和翻译此篇文章">🔄</button>`;
        
        html += `<p style="text-align: center; ${cnStyle} font-size: 14pt; font-weight: bold;">${article.title_cn || article.title || '...'}</p>`;
        
        if (article.is_editors_suggestion && article.editors_blurb_cn) {
            const style = `font-family: '宋体', 'SimSun', serif; font-size: 12pt; font-weight: bold; color: #FF0000;`;
            html += `<p><span style="${style}">[编辑推荐] </span><span style="${style}">${article.editors_blurb_cn}</span></p>`;
        } else if (article.is_featured_in_physics) {
            const style = `font-family: '宋体', 'SimSun', serif; font-size: 12pt; font-weight: bold; color: #007bff;`;
            html += `<p><span style="${style}">[物理学专题]</span></p>`;
        }

        html += `<p style="text-align: justify; ${cnStyle} font-size: 12pt;">${article.abstract_cn || article.abstract_raw || '摘要待处理...'}</p><br/>`;
        
        html += `<p>${article.title_en_formatted || article.title || 'N/A'}</p><p>${article.authors || 'N/A'}</p><p>${article.journal_reference || 'N/A'}</p>`;
        if (article.link !== 'N/A') html += `<p><a href="${article.link}" target="_blank">${article.link}</a></p>`;
        html += `</div>`;
    });
    html += `</div>`;
    return { html, text: '...' };
}
